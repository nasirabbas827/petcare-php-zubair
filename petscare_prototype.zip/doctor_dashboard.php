<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Doctor Dashboard</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{
            background-color:azure;
        }
        h1, h2, h3{
            text-align: center;
            margin: 30px;
        }
    </style>
</head>
<body>
    <?php include('navbar.php'); ?>
    <div class="container">
        <h2 class="mt-4">Welcome to the Doctor Dashboard</h2>
        
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Appointment Schedule</h5>
                        <!-- Add appointment schedule content here -->
                        <ul>
                            <li>Appointment 1: Date and Time</li>
                            <li>Appointment 2: Date and Time</li>
                            <!-- Add more appointments as needed -->
                        </ul>
                        <a href="#" class="btn btn-primary">View Schedule</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Patient Information</h5>
                        <!-- Add patient information content here -->
                        <ul>
                            <li>Patient 1: Name, Age, Condition</li>
                            <li>Patient 2: Name, Age, Condition</li>
                            <!-- Add more patient information as needed -->
                        </ul>
                        <a href="#" class="btn btn-primary">View Patients</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>

