<!DOCTYPE html>
<html>
<head>
    <title>PetsCare</title>
    <!-- Add Bootstrap CDN link here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style>
                body{
            background-color:azure;
        }
        h1, h2, h3{
            text-align: center;
            margin: 30px;
        }
        .jumbotron {
            background-color: #3498db; /* Change background color */
            color: white;
            text-align: center;
        }

        .jumbotron h1 {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        .jumbotron p {
            font-size: 1.5rem;
        }

        /* Additional styles for the About PetsCare section */
        .about-section {
            padding: 50px;
        }

        /* Additional styles for statistics */
        .statistics-section {
            background-color: #f2f2f2;
            padding: 20px;
            text-align: center;
        }

        /* Additional styles for the contact form */
        .contact-form {
            padding: 20px;
        }

        /* Additional styles for the footer */
        .footer {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php include('navbar.php'); ?>

    <div class="jumbotron text-center">
        <h1>Welcome to PetsCare</h1>
        <p>Your One-Stop Destination for Pets and Veterinary Services</p>
        <a href="login.php" class="btn btn-primary btn-lg">Login to Buy</a>
    </div>

    <div class="container about-section">
        <h2>About PetsCare</h2>
        <p>PetsCare is a dedicated platform for pet lovers, offering a wide range of services and products for your beloved pets. Whether you're looking for veterinary care, pet adoption, or quality pet supplies, PetsCare has you covered.</p>
    </div>

    <div class="container statistics-section">
        <h2>Statistics</h2>
        <div class="row">
            <div class="col-md-4">
                <h3>Total Users</h3>
                <p>500,000+</p>
            </div>
            <div class="col-md-4">
                <h3>Total Pets</h3>
                <p>250,000+</p>
            </div>
            <div class="col-md-4">
                <h3>Total Doctors</h3>
                <p>5,000+</p>
            </div>
        </div>
    </div>

    <div class="container contact-form">
        <h2>Contact Us</h2>
        <form>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" placeholder="Your Name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" placeholder="Your Email">
            </div>
            <div class="form-group">
                <label for="message">Message:</label>
                <textarea class="form-control" id="message" rows="4" placeholder="Your Message"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <div class="footer">
        <p>&copy; 2023 PetsCare. All rights reserved.</p>
    </div>

</body>
</html>
